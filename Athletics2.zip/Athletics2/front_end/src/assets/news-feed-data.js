export const newsData = [
    {
        id:1,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
    {
        id:2,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
    {
        id:3,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
    {
        id:4,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
    {
        id:5,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
    {
        id:6,
        img: '../images/hero-images/image2.jpg',
        date: "October 14, 2024",
        title: "Berekuso Cleanup and Friendly Match"
    },
];
